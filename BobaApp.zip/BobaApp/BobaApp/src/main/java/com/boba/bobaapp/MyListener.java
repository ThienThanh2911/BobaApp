/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.boba.bobaapp;

import com.boba.pojo.Product;

/**
 *
 * @author ADMIN
 */
public interface MyListener {
    public void onClickListener(Product product);
}
